
  
<script>
  import Versions from './components/Versions.svelte'
  import electronLogo from './assets/logowhite.gif'
  import { Button, Col, Row, Container } from '@sveltestrap/sveltestrap';
  import FilePond from './components/FilePond.svelte'
  import LayoutSettings from "./components/LayoutSettings.svelte";
  import { Modals, closeModal } from 'svelte-modals'
  import Uploads from './components/Uploads.svelte';
  import NewVersion from './components/newVersion.svelte';
  let version = '1.0.0'
  let newversion = 'x'
  let showVersionPage = false

  const ipcHandle = () => window.electron.ipcRenderer.send('ping');
  let uid,key;
  let apicontainer = true
  let filepondcontainer = false
  let alert = false
  let uploaded_files = []
  $: MAX_CONCURRENT_UPLOADS = 5
  let settings_view = false
  $: uploads = false
  $: files = [];
  $: uploadProgress = [];
  $: filesTable = [];
  $: textarealinks = '';

   async function checkVersion(){
    let response = await fetch('https://api.swiftload.io/api/appVersion')
    let data = await response.json()
    if (data.version != version) {
      showVersionPage = true
      apicontainer = false
      newversion = data.version
      console.log('New version available')
      Modals.open('newversion')
    }
    return;
   }

   checkVersion()

  
  function handleFiles(event) {
    files = Array.from(event.target.files);
    uploadProgress = files.map(file => ({
      file: file,
      name: file.name,
      progress: 0,
      status:'Ready',
      link: '',
      speed: 0,
      total: file.size,
      remainingTime: 0
    }));
    filesTable = files
    //uploadFiles(); // Automatically start uploading after files are selected
  }


  function toggleUploads() {
    console.log(uploadProgress,files,filesTable)
    console.log(uploads)
    if (uploads) {
      uploads = false;
      filepondcontainer = true
    } else {
      uploads = true;
      filepondcontainer = false
    }
  }

  function toggleSettings(s) {
    MAX_CONCURRENT_UPLOADS = s
    if (settings_view) {
      settings_view = false;
      filepondcontainer = true

    } else {
      settings_view = true;
      filepondcontainer = false
    }
    console.log(MAX_CONCURRENT_UPLOADS)
  }

 
  function checkAPIKEY(key) {
     fetch(`https://api.swiftload.io/api/${key}`) 
      .then(response => response.json())
      .then(data => {
        if (data.status == 200) {
          console.log(data)
          apicontainer = false
          filepondcontainer = true
          alert = false

        } else {
          alert = true
        }
      })
  }



</script>




{#if apicontainer}
<Container {apicontainer}>
  <Row>
    <Col>
      <div class="main-index">
        <img alt="logo" class="logo" src={electronLogo} />
        <div class="input-group form-control" style="background-color: #312f33;">
          {#if alert}
          <div class="alert alert-danger" role="alert">
            The API key is invalid. Please enter a valid API key.
          </div>
                    {/if}
                    <b style="color:white">UID: </b>
                    <input type="text" class="form-control fields" bind:value={uid} placeholder="UID" style="width: 100%;">

          <b style="color:white">API Key: </b>
          <input type="text" class="form-control fields" bind:value={key} placeholder="API KEY" style="width: 100%;">
          <Button color="secondary" class="submit-btn" on:click={checkAPIKEY(key)} outline > Submit</Button>
        </div>
        
      </div>
   


    </Col>
  </Row>
</Container>
{/if}

{#if filepondcontainer}
      <FilePond {toggleSettings} {MAX_CONCURRENT_UPLOADS} {uid} {key} {electronLogo} {toggleUploads} {uploaded_files} {uploadProgress} {files} {filesTable} {handleFiles}/>
{/if}

{#if uploads}
      <Uploads {uploads} {toggleUploads} {uploaded_files} {textarealinks}/>
{/if}

{#if settings_view}
<Container>
  <Row>
    <Col>
<LayoutSettings {toggleSettings} {electronLogo} {MAX_CONCURRENT_UPLOADS}></LayoutSettings>
</Col>
</Row> 
</Container>
{/if}

{#if showVersionPage}
<Container>
  <Row>
    <Col>
<NewVersion {version} {newversion} {electronLogo}></NewVersion>
</Col>
</Row> 
</Container>
{/if}

<style>
    .backdrop {
    position: fixed;
    top: 0;
    bottom: 0;
    right: 0;
    left: 0;
    background: rgba(0,0,0,0.50)
    }
    
  .main-index {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100vh;
  }

  .logo {
    margin-bottom: 20px;
  }

  .input-group {
    display: flex;
    flex-direction: column;
    width: 100%;
  }

  .fields {
    margin-bottom: 10px; /* Spacing between input fields */
    width: 100%; /* Make the input fields take up the full width of the parent container */

  }

  .submit-btn {
    width: auto;
    align-self: center; /* Center the button horizontally */
  }
</style>
