<script>
   export let uploaded_files
   export let toggleUploads; 
   export let textarealinks


   for (let i = 0; i < uploaded_files.length; i++) {
    console.log(uploaded_files[i]);
    textarealinks += uploaded_files[i].name + '\n' +  uploaded_files[i].link + '\n';
   }

   function directlinks(type) {
    textarealinks = '';
    for (let i = 0; i < uploaded_files.length; i++) {
        if (type == 'v') {
            console.log('direct version')
            textarealinks += uploaded_files[i].name + '\n' +  uploaded_files[i].link.split('/e/').join('/v/') + '\n';
        } else {
            textarealinks += uploaded_files[i].name + '\n' +  uploaded_files[i].link + '\n';
        }
    }
    
   }

</script>


<div class="export-btns">
<button class="btn btn-success" on:click={() => directlinks('v')}>Direct Links</button>
<button class="btn btn-info" on:click={() => directlinks('e')}>Embed Links</button>
</div> <br>
<textarea name="" class="form-control textarea" id="" bind:value={textarealinks}></textarea>

<button class="upload-view-btn" on:click={() => toggleUploads()} tooltip="d">
    <i class="bi bi-list"></i> <!-- Using Bootstrap icon for upload -->
  </button>

<style>
    .export-btns {
       float: right;
       padding: 1%;
    }
    .textarea {
     background-color: #343a40;
     top: 1%;
     color: white;
     height: 60vh;
    }
    textarea:focus, input:focus{
        background-color: #343a40;
        color: white;
}

.upload-view-btn {
    position: fixed;
    z-index: 1050; /* Higher than typical content z-index */
    right: 163px;
    bottom: 20px;
    width: 60px;
    height: 60px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    background-color: #b9acacb4;
    color: white;
    border: none;
    cursor: pointer;
    box-shadow: 0 4px 8px rgba(0,0,0,0.5); /* Optional: Adds shadow for better visibility */
  }

</style>