<script>
export let electronLogo 
export let MAX_CONCURRENT_UPLOADS
export let toggleSettings

console.log(MAX_CONCURRENT_UPLOADS)




</script>
        
        <div class="main-index">
          <img alt="logo" class="logo" src={electronLogo} />


          <div class="input-group form-control" style="background-color: #312f33;">
         
          <b style="color:white">Number of Uploads at same time: </b>
       <input type="number" min="1" max="10" class="form-control fields" bind:value={MAX_CONCURRENT_UPLOADS}   style="width: 100%;">

       <button class="btn btn-secondary" style="float: right;" on:click={() => toggleSettings(MAX_CONCURRENT_UPLOADS)}>Save</button>

           
          </div>
          
        </div>
        
  <!-- Settings button -->
  <button class="settings-btn" on:click={toggleSettings(MAX_CONCURRENT_UPLOADS)}>
    <i class="bi bi-gear"></i>
  </button>

        <style>
               
  .main-index {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100vh;
  }
  .logo {
    top: 0%;
    position: absolute;
    left: 1%;
  }

  .settings-btn {
      position: fixed;
      z-index: 1050; /* Higher than typical content z-index */
  
      right: 90px; /* Adjust position to not overlap with the upload button */
      bottom: 20px;
      width: 60px;
      height: 60px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 24px;
      background-color: #28a745; /* Green for settings */
      color: white;
      border: none;
      cursor: pointer;
      box-shadow: 0 4px 8px rgba(0,0,0,0.5);
    }
        </style>