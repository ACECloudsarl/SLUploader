<script>
    export let toggleUploads;
    export let uploaded_files
    export let files
    export let uploadProgress
    export let filesTable
    export let handleFiles
    export let uid
    export let key
    export let MAX_CONCURRENT_UPLOADS
    export let toggleSettings
    let defaultModal = false;
    let tablesize = '85vh'
  const RETRY_LIMIT = 3;
  let activeUploads = 0;
  let currentIndex = 0;
  
  let testNumer = 1

  async function getUploadServer(){
    let response = await fetch(`https://api.swiftload.io/api/GetUploadServer/${key}`)
    let data = await response.json()
    console.log(data.url)
    return data.url
  }

  async function handleUpload(file, index) {
    activeUploads++;
    try {
      await uploadFile(file, index);
      uploadProgress[index].status = 'Completed';
    } catch (error) {
      console.error('Upload failed for', file.name, ':', error.message);
      uploadProgress[index].status = 'Failed';
      // Optionally retry the upload if it fails
      if (uploadProgress[index].retryCount < RETRY_LIMIT) {
        uploadProgress[index].retryCount++;
        setTimeout(() => handleUpload(file, index), 2000); // Retry after 2 seconds
        return;
      }
    } finally {
      activeUploads--;
      // Start next upload if there are more files to process
      if (currentIndex < files.length) {
        handleUpload(files[currentIndex], currentIndex);
        currentIndex++;
      }
    }
  }

  async function deleteFile(file,index) {
    console.log(index)
    uploadProgress.splice(index, 1);
    files.splice(index, 1);
    filesTable.splice(index, 1);

    uploadProgress = uploadProgress
  }

  async function uploadFile(file, index) {
    let startTime = Date.now();  // Ensure startTime is properly scoped within the function
    uploadProgress[index].status = 'Uploading...';
    let server_url = await getUploadServer()
  
    return new Promise((resolve, reject) => {
      const formData = new FormData();
      formData.append('file', file);
      const xhr = new XMLHttpRequest();
      xhr.timeout = 300000;  // Set timeout to 5 minutes
      xhr.open('POST', `${server_url}?uid=${uid}&key=${key}`);

      xhr.upload.onprogress = event => {
        if (event.lengthComputable) {
          const currentTime = Date.now();
          const timeElapsed = (currentTime - startTime) / 1000;  // Calculate elapsed time in seconds
          const currentSpeed = event.loaded / timeElapsed;  // Calculate upload speed in bytes per second

          uploadProgress[index].progress = (event.loaded / event.total) * 100;  // Calculate progress percentage
          uploadProgress[index].speed = currentSpeed / 1024;  // Convert speed to KB/s
          uploadProgress[index].remainingTime = ((event.total - event.loaded) / currentSpeed).toFixed(2);  // Calculate remaining time in seconds
        }
      };

      xhr.onload = () => {
        if (xhr.status === 200) {
          uploadProgress[index].status = 'Completed';
          let response = JSON.parse(xhr.response)
          uploaded_files.push({name:file.name,link:`https://swiftload.io/e/${response.code}`,code:response.code})
          uploadProgress[index].link = `https://swiftload.io/e/${response.code}`;

          resolve(JSON.parse(xhr.response));
        } else {
          reject(new Error('Server responded with status: ' + xhr.status));
        }
      };

      xhr.onerror = () => reject(new Error('Network or server error'));
      xhr.ontimeout = () => reject(new Error('Upload timed out'));

      xhr.send(formData);
    });
  }

  function uploadFiles() {
    // Start uploads while maintaining maximum concurrency limit
    while (activeUploads < MAX_CONCURRENT_UPLOADS && currentIndex < files.length) {
      handleUpload(files[currentIndex], currentIndex);
      currentIndex++;
    }
  }



 
  function triggerFileInput() {
    document.querySelector('.file-input').click();
  } 


</script>


<input class="file-input" type="file" multiple bind:files on:change={handleFiles} on:change={() => uploadFiles()}>
<button class="upload-btn" on:click={triggerFileInput}>
  <i class="bi bi-upload"></i> <!-- Using Bootstrap icon for upload -->
</button>

  <!-- Settings button -->
  <button class="settings-btn" on:click={toggleSettings(MAX_CONCURRENT_UPLOADS)} {testNumer}>
    <i class="bi bi-gear"></i>
  </button>

  <button class="upload-btn" on:click={triggerFileInput}>
    <i class="bi bi-upload"></i> <!-- Using Bootstrap icon for upload -->
  </button>
  
  <button class="upload-view-btn" on:click={() => toggleUploads()}>
    <i class="bi bi-list"></i> <!-- Using Bootstrap icon for upload -->
  </button>

  <button class="upload-trash-btn" on:click={() => uploadProgress = []}>
    <i class="bi bi-trash"></i> <!-- Using Bootstrap icon for upload -->
  </button>

 

 <div class="table-container" style="max-height: {tablesize};">

<table class="table table-dark table-striped dark-table">
  <thead>
    <tr>
      <th>File Name</th>
      <th>Status</th>

      <th>Progress</th>
      <th>Speed (KB/s)</th>
      <th>Remaining Time (s)</th>
      <th>Link</th>

      <th>Actions</th>

    </tr>
  </thead>
  <tbody>
    {#each uploadProgress as progress, index}
      <tr>
        <td>{progress.name}</td>
        <td>{progress.status}</td>

        <td>
          <div class="progress">
            <div class="progress-bar" role="progressbar" style="width: {progress.progress}%" aria-valuenow={progress.progress} aria-valuemin="0" aria-valuemax="100"></div>
          </div>
        </td>
        <td>{Math.round(progress.speed)}</td>
        <td>{Math.round(progress.remainingTime)}</td>
        <td>{progress.link}</td>
        <td><button class="btn btn-danger" on:click={deleteFile(progress.file,index)}>Delete</button> <button class="btn btn-info" on:click={() => uploadFile(progress.file,index)}>Restart</button></td>

      </tr> 
    {/each}
  </tbody>
</table>





</div>
{#if uploadProgress.length > 0}
<button class="btn btn-success" style="float: right;" on:click={() => uploadFiles()}>Upload</button>
{/if}


<style>

  .table-container {
      overflow-y: auto; /* Enables vertical scrolling within the container */
      background-color: #343a40; /* Matches the table background */
      position: absolute; /* Ensures the positioning context is correct */
      width: 100%; /* Ensures the container uses the full available width */
      min-height: 85vh;

  }
  
    .dark-table {
      color: #f8f9fa;
      background-color: #343a40;
      width: 100%;
      top: 0%;
      min-height: 30vh;
    }
    .dark-table th, .dark-table td {
      border-color: #454d55;
    }
    .upload-btn {
      position: fixed;
      z-index: 1050; /* Higher than typical content z-index */
      right: 20px;
      bottom: 20px;
      width: 60px;
      height: 60px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 24px;
      background-color: #b9acacb4;
      color: white;
      border: none;
      cursor: pointer;
      box-shadow: 0 4px 8px rgba(0,0,0,0.5); /* Optional: Adds shadow for better visibility */
    }
  
    .upload-view-btn {
      position: fixed;
      z-index: 1050; /* Higher than typical content z-index */
      right: 163px;
      bottom: 20px;
      width: 60px;
      height: 60px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 24px;
      background-color: #b9acacb4;
      color: white;
      border: none;
      cursor: pointer;
      box-shadow: 0 4px 8px rgba(0,0,0,0.5); /* Optional: Adds shadow for better visibility */
    }

    .upload-trash-btn {
      position: fixed;
      z-index: 1050; /* Higher than typical content z-index */
      right: 234px;
      bottom: 20px;
      width: 60px;
      height: 60px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 24px;
      background-color: #ed3e3eb4;;
      color: white;
      border: none;
      cursor: pointer;
      box-shadow: 0 4px 8px rgba(0,0,0,0.5); /* Optional: Adds shadow for better visibility */
    }
  
    .file-input {
      display: none; /* Hide the file input */
    }
  
      /* Your existing styles, plus styles for the settings button */
      .settings-btn {
      position: fixed;
      z-index: 1050; /* Higher than typical content z-index */
  
      right: 90px; /* Adjust position to not overlap with the upload button */
      bottom: 20px;
      width: 60px;
      height: 60px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 24px;
      background-color: #28a745; /* Green for settings */
      color: white;
      border: none;
      cursor: pointer;
      box-shadow: 0 4px 8px rgba(0,0,0,0.5);
    }
  
    .dropdown-menu {
      position: fixed;
      right: 20px; /* Align with the button */
      bottom: 100px; /* Show above the button */
      background: #343a40;
      border: 1px solid #454d55;
      border-radius: 0.25rem;
      width: auto;
      padding: 0.5rem;
      display: none; /* Initially hidden */
    }
    .dropdown-item {
      color: #f8f9fa;
      padding: 0.25rem 1rem;
      cursor: pointer;
    }
    .dropdown-item:hover {
      background-color: #495057;
    }
    .show {
      display: block;
    }
  
    .settings {
      position: fixed;
      right: 20px;
      top: 20px;
      overflow: hidden;
      position: absolute;
    }
  
  </style>